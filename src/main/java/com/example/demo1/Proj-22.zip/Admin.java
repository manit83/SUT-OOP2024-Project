package com.example.demo1;

public class Admin extends User{
    Admin(String userName, String password, String email, String nickname) {
        super(userName, password, email, nickname);
    }
    void addCard(String name,int def , int dur , int dam , int level ,int upgradeConst){

    }
    void removeCard(Card card){

    }
    void seeAllPlayers(){

    }
}
